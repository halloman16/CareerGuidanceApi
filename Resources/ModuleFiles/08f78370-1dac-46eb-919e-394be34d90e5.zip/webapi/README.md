## Run Locally

Clone the project

Download dotnet 7: https://dotnet.microsoft.com/en-us/download/dotnet/7.0

if you need change ip: Properties -> launchSettings.json -> http profile

Install dependencies
  dotnet restore

Start the server
  dotnet run

