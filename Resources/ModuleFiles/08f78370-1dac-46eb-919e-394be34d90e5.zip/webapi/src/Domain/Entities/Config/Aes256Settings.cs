namespace webApiTemplate.src.Domain.Entities.Config
{
    public class Aes256Settings
    {
        public string Key { get; set; }
        public string IV { get; set; }
    }
}