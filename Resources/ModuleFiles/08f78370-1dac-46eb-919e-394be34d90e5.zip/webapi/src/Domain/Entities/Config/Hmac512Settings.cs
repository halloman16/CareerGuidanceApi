namespace webApiTemplate.src.Domain.Entities.Config
{
    public class Hmac512Settings
    {
        public string Key { get; set; }
    }
}