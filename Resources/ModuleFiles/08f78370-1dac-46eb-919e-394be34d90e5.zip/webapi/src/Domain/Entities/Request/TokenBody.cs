namespace webapi.src.Domain.Entities.Request
{
    public class TokenBody
    {
        public string Token { get; set; }
    }
}