namespace webapi.src.Domain.Entities.Response
{
    public class ModuleBody
    {
        public string Name { get; set; }
        public string? UrlFile { get; set; }
    }
}