namespace webapi.src.Domain.Entities.Response
{
    public class UserModuleBody
    {
        public Guid UserModuleId { get; set; }
        public string ModuleName { get; set; }
    }
}